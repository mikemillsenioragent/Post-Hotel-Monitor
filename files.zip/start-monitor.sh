#!/bin/bash
# Post Hotel Monitor — local server launcher
# Saves the HTML file and serves it so browser notifications work

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PORT=8743

echo ""
echo "  Posthotel Leavenworth Monitor"
echo "  ─────────────────────────────"

# Check for Python 3
if command -v python3 &>/dev/null; then
  echo "  Starting server at http://localhost:$PORT"
  echo "  Opening browser..."
  echo "  Press Ctrl+C to stop."
  echo ""
  # Open browser after short delay
  (sleep 1 && open "http://localhost:$PORT/posthotel-monitor.html" 2>/dev/null || xdg-open "http://localhost:$PORT/posthotel-monitor.html" 2>/dev/null) &
  cd "$SCRIPT_DIR"
  python3 -m http.server $PORT
elif command -v python &>/dev/null; then
  (sleep 1 && open "http://localhost:$PORT/posthotel-monitor.html" 2>/dev/null || xdg-open "http://localhost:$PORT/posthotel-monitor.html" 2>/dev/null) &
  cd "$SCRIPT_DIR"
  python -m SimpleHTTPServer $PORT
else
  echo "  Python not found. Please open posthotel-monitor.html directly in your browser."
  echo "  Note: browser notifications require serving via localhost."
fi
