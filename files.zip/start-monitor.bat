@echo off
:: Post Hotel Monitor — Windows launcher
title Posthotel Monitor

echo.
echo   Posthotel Leavenworth Monitor
echo   ─────────────────────────────

set PORT=8743
cd /d "%~dp0"

where python >nul 2>&1
if %errorlevel%==0 (
  echo   Starting server at http://localhost:%PORT%
  echo   Opening browser...
  echo   Press Ctrl+C to stop.
  echo.
  start "" "http://localhost:%PORT%/posthotel-monitor.html"
  python -m http.server %PORT%
) else (
  echo   Python not found.
  echo   Opening file directly - note that browser notifications may not work.
  start "" "%~dp0posthotel-monitor.html"
  pause
)
